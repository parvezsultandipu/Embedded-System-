#include <18F4431.h>                                                        
#device  ADC = 10                                                        
#fuses   HS, NOWDT                                                    
#use     delay(clock=4 MHZ)
#include "piclcd.c"

float value1, voltage1;
float value2, voltage2, temp;

void main()
{
   lcd_init();    // START LCD  
   setup_adc(ADC_CLOCK_INTERNAL);   // ADC SYNC
   setup_adc_ports(ALL_ANALOG);     // SET ALL THE ANx pins as ANALOG INPUT
 
   WHILE(1)    // LOOP FOREVER
   {      
     set_adc_channel (0) ;    
     value1 = read_adc();    
     delay_us(10);        
     voltage1 = value1*0.004887;
     
     lcd_gotoxy(1, 1);    
     printf(LCD_PUTC, "V1=%f A=%f",voltage1, value1);  

     set_adc_channel (1) ;    
     value2 = read_adc();    
     delay_us(10);        
     voltage2 = value2*0.004887;
     
     temp = voltage2*100;
     lcd_gotoxy(1, 2);
     printf(LCD_PUTC, "V2=%f T=%f C", voltage2,temp);
     
     if(temp>50)
     {
      lcd_clear();    
      lcd_gotoxy(1, 1);
      printf(LCD_PUTC, "TOO HOT!");
     
      output_toggle(pin_c0);
      delay_ms(1000);          
     }
       
     //delay_ms(1);    
    // lcd_clear();       // use it to clear lcd    
   }  
}
